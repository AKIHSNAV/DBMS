<?php
$con = mysqli_connect("127.0.0.1","root","IIITDelhi123@","quickcart");
if(!$con){
    die(mysqli_error($con));
}
?>